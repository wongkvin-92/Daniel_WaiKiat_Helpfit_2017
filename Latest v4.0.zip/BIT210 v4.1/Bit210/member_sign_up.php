<?php
	session_start();
	 include("config.php");

	$fullName = $_POST['fullname'];
	$userName = $_POST['username'];
	$password = $_POST['password'];
	$cPassword = $_POST['confirmpass'];
	$email = $_POST['emailadd'];

	$userType = "Member";
	$address = $_POST['address'];
	$level = $_POST['level'];
	$specialty = "NULL";


	if (isset($_POST['submit'])) {

		if (!empty($fullName)&&!empty($userName)&&!empty($password)&&!empty($email)&&!empty($address)&&!empty($level)) {

			$checkEmail = mysqli_query($conn,"SELECT email FROM member where email ='$email'");

			$row = mysqli_fetch_array($checkEmail);
			$data = $row[0];
			// to check if email exist in the database
			if($data){
				//to pass the sessions back to the member_signUpForm.php page
				$_SESSION['userName'] = $userName;
				$_SESSION['fullName'] = $fullName;
				$_SESSION['emailadd'] = $email;
				$_SESSION['address'] = $address;

				echo '<script language = "javascript">';
				echo 'alert("You have already sign Up!!")';
				echo '</script>';
				echo  "<script> window.location.assign('member_signUpForm.php'); </script>";
			}else{

				$checkUserName = mysqli_query($conn,"SELECT email FROM member where userName ='$userName'");

				$row = mysqli_fetch_array($checkUserName);
				$data1 = $row[0];
				//to check if username existed in the database
				if($data1){
					$_SESSION['userName'] = $userName;
					$_SESSION['fullName'] = $fullName;
					$_SESSION['emailadd'] = $email;
					$_SESSION['address'] = $address;

					echo '<script language = "javascript">';
					echo 'alert("This userName already exist!!")';
					echo '</script>';
					echo  "<script> window.location.assign('member_signUpForm.php'); </script>";

				}else{
					//To validate is the password field and confirm password field are the same
					if ($password == $cPassword) {

						$sql = "INSERT INTO member (fullName, userName, password, email, level, address)	VALUES ('$fullName','$userName','$password','$email', '$level','$address')";

						if ($conn->query($sql) == TRUE && mysqli_affected_rows($conn) >0){

							echo '<script language = "javascript">';
							echo 'alert("Record Added successfully")';
							echo '</script>';
							echo  "<script> window.location.assign('homepage.php'); </script>";
						}
						else
						{
							$_SESSION['userName'] = $userName;
							$_SESSION['fullName'] = $fullName;
							$_SESSION['emailadd'] = $email;
							$_SESSION['address'] = $address;
							echo " Error Adding record: ".$conn->error;
							echo  "<script> window.location.assign('member_signUpForm.php'); </script>";
						}

					}else{
						$_SESSION['userName'] = $userName;
						$_SESSION['fullName'] = $fullName;
						$_SESSION['emailadd'] = $email;
						$_SESSION['address'] = $address;
					echo '<script language = "javascript">';
					echo 'alert("The password must be same")';
					echo '</script>';
					echo  "<script> window.location.assign('member_signUpForm.php'); </script>";
					}
				}
			}

		}else{
			$_SESSION['userName'] = $userName;
			$_SESSION['fullName'] = $fullName;
			$_SESSION['emailadd'] = $email;
			$_SESSION['address'] = $address;
				echo '<script language = "javascript">';
				echo 'alert("All the field most be completed")';
				echo '</script>';
				echo  "<script> window.location.assign('member_signUpForm.php'); </script>";
			}
	}



	$conn->close();
?>
