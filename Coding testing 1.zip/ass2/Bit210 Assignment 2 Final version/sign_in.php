<?php
	//error_reporting(0);
	session_start();
	$username = $_POST['username'];
	$password = $_POST['password'];

	

	$conn = mysqli_connect("localhost","root","","helpfit");
	
	if ($conn->connect_error){
		die("Connection failed: ".$conn->connect_error);
		//echo "testing 1";
	}

	if (isset(($_POST['submit']))) {
		//echo "testing 2";
		if (!empty($username)&&!empty($password)) {

			

			$result = $conn->query("SELECT * FROM user WHERE userName='$username' and password='$password'");
			

			 while($rs = $result->fetch_array())
			{
				
				
				$_SESSION['user_ID'] = $rs["userID"];
                 $_SESSION['user_Name'] = $rs['userName'];
                 $_SESSION['user_Email'] = $rs['email'];
                 $_SESSION['user_Password'] = $rs['password'];
                 $_SESSION['user_Type'] = $rs['userType'];
			}

			 if ($_SESSION['user_Name'] == $username && $_SESSION['user_Password'] == $password) {
			 	
			 	if ($_SESSION['user_Type'] == "Trainer") {
			 	 	echo  "<script> window.location.assign('trainer_homepage.html'); </script>";
			 	 } else{
			 	 	echo  "<script> window.location.assign('member_homepage.html'); </script>";
			 	 }

			 }else{
			 	echo '<script language = "javascript">';
             	echo 'alert("Username and Password  are not found.")';
             	echo '</script>';
                echo  "<script> window.location.assign('login.html'); </script>";
			 }

			
		}else{
			echo '<script language = "javascript">';
          	echo 'alert("Please fill all the field.")';
          	echo '</script>';
          	echo  "<script> window.location.assign('login.html'); </script>";
		}
	}

	

	$conn->close();

?>
