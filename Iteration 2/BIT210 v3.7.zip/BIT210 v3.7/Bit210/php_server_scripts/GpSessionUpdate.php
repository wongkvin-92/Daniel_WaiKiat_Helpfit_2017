<?php
	session_start();

	$sessionID = $_SESSION['GpSessionUpdate'];
	$countPart = $_SESSION['countPart'];
	

	$title = $_POST['title'];
	$date = $_POST['date'];
	$time = $_POST['time'];
	$fee = $_POST['fee'];
	$maxParticipants = $_POST['maxParticipant'];
	$type = $_POST['classType'];
	$status1 = "Available";
	$status2 = "FULL";
	



	$conn = mysqli_connect("localhost","root","","helpfit");

	if ($conn->connect_error){
		die("Connection failed: ".$conn->connect_error);
	}

	if (isset($_POST['submit'])) {

		if (!empty($title)&&!empty($date)&&!empty($time)&&!empty($fee)) {
			if(is_numeric($fee)){

				if ($maxParticipants  <= $countPart) {
					$sql1 = "UPDATE trainingsession SET titel='$title',date='$date',time='$time',feee='$fee',status='$status2',classType='$type',maxParticipants='$maxParticipants' Where sessionID = '$sessionID'";

						if ($conn->query($sql1) == TRUE && mysqli_affected_rows($conn) >0){

							echo '<script language = "javascript">';
							echo 'alert("Record Udated successfully")';
							echo '</script>';
							echo  "<script> window.location.assign('trainer_history_group.php'); </script>";
						}
						else
						{
							echo " Error Adding record: ".$conn->error;
							
						}
				}else if($maxParticipants  > $countPart){

					$sql = "UPDATE trainingsession SET titel='$title',date='$date',time='$time',feee='$fee', classType='$type', maxParticipants='$maxParticipants' Where sessionID = '$sessionID'";

						if ($conn->query($sql) == TRUE && mysqli_affected_rows($conn) >0){

							echo '<script language = "javascript">';
							echo 'alert("Record Udated successfully")';
							echo '</script>';
							echo  "<script> window.location.assign('trainer_history_group.php'); </script>";
						}
						else
						{
							echo " Error Adding record!: ".$conn->error;
							
						}
				}

					
				} else{
					
					echo '<script language = "javascript">';
					echo 'alert("Fee must be in numeric format!")';
					echo '</script>';
					echo  "<script> window.location.assign('trainer_session_group_edit.php'); </script>";
				}
		}else{
				
				echo '<script language = "javascript">';
				echo 'alert("All the field most be completed")';
				echo '</script>';
				echo  "<script> window.location.assign('trainer_session_group_edit.php'); </script>";
			}

	}



	$conn->close();
?>
