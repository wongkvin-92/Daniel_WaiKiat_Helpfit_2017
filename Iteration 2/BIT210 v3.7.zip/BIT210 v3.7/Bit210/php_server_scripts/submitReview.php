<?php
	//error_reporting(0);
	session_start();
	$rateValue = $_POST['rating'];
  $memberID = $_SESSION['user_ID'];
	$sess_id =$_POST['session_id'];
	$comment =$_POST['comment'];

	//$rating = $ratevalue .' '.$ratevalue1.' '.$

	$conn = mysqli_connect("localhost","root","","helpfit");

	if (mysqli_connect_errno($conn)) {
		echo "Failed to connect to MySQL: ".mysqli_connect_errno();
	}

			$result="SELECT trainerID from trainingsession where sessionID =  '$sess_id'";
			$result = $conn->query($result);
			$result = $result->fetch_row();
			$trainerId = $result[0];


			$insert="INSERT INTO review (Rating, comment, sessionID, memberID, trainerID) VALUES ('$rateValue','$comment','$sess_id','$memberID','$trainerId')";

			if ($conn->query($insert) == TRUE && mysqli_affected_rows($conn) >0){

				echo '<script language = "javascript">';
				echo 'alert("Record Added successfully")';
				echo '</script>';
				header("location: homepage.php");

			}
			else
			{
				echo " Error Adding record: ".$conn->error;
			}


$conn->close();
?>
