<?php
	session_start();

	$sessionID = $_SESSION['PrSessionUpdate'];
	

	$title = $_POST['title'];
	$date = $_POST['date'];
	$time = $_POST['time'];
	$fee = $_POST['fee'];
	



	$conn = mysqli_connect("localhost","root","","helpfit");

	if ($conn->connect_error){
		die("Connection failed: ".$conn->connect_error);
	}

	if (isset($_POST['submit'])) {

		if (!empty($title)&&!empty($date)&&!empty($time)&&!empty($fee)) {
			if(is_numeric($fee)){

					$sql = "UPDATE trainingsession SET titel='$title',date='$date',time='$time',feee='$fee' Where sessionID = '$sessionID'";

						if ($conn->query($sql) == TRUE && mysqli_affected_rows($conn) >0){

							echo '<script language = "javascript">';
							echo 'alert("Record Udated successfully")';
							echo '</script>';
							echo  "<script> window.location.assign('trainer_history_personal.php'); </script>";
						}
						else
						{
							echo " Error Adding record: ".$conn->error;
							
						}
				} else{
					
					echo '<script language = "javascript">';
					echo 'alert("Fee must be in numeric format!")';
					echo '</script>';
					echo  "<script> window.location.assign('trainer_session_personal_edit.php'); </script>";
				}
		}else{
				
				echo '<script language = "javascript">';
				echo 'alert("All the field most be completed")';
				echo '</script>';
				echo  "<script> window.location.assign('trainer_session_personal_edit.php'); </script>";
			}

	}



	$conn->close();
?>
