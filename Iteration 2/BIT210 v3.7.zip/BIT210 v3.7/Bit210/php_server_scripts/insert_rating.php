<?php
	//error_reporting(0);
	session_start();
	$rateValue = $_POST['value'];
	$ID = $_SESSION['user_ID'];
	$comment = $_POST['content'];
	//$rating = $ratevalue .' '.$ratevalue1.' '.$

	$conn = mysqli_connect("localhost","root","","helpfit");

	if (mysqli_connect_errno($conn)) {
		echo "Failed to connect to MySQL: ".mysqli_connect_errno();
	}



			$insert="INSERT INTO review (Rating, comment, memberID ) VALUES ('$rateValue','$comment','$ID')";

			if ($conn->query($insert) == TRUE && mysqli_affected_rows($conn) >0){

				echo '<script language = "javascript">';
				echo 'alert("Record Added successfully")';
				echo '</script>';
				header("location: homepage.php");

			}
			else
			{
				echo " Error Adding record: ".$conn->error;
			}


$conn->close();
?>
