$(".btnGetRate").click(function() {
   var $value = document.getElementById("rate").onclick();
   console.log($value);
  //window.location.href = "insert_rating.php?value=" + $value ;
});