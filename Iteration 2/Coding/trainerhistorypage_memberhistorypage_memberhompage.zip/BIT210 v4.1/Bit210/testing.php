<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>An Anonymous Pen on CodePen</title>
  
  
  <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css'>
<link rel='stylesheet prefetch' href='https://cdn.datatables.net/t/bs/jq-2.2.0,dt-1.10.11/datatables.min.css'>

  
  
</head>

<body>
  <button class="btn btn-primary" data-toggle="modal" data-target="#test">Open Modal</button>

<div class="modal fade" id="test">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
        <h4 class="modal-title">Title</h4>
      </div>
      <div class="modal-body">
        <table class="table datatable table-bordered" width="100%">
          <thead>
            <tr>
              <th>Title 1</th>
              <th>Title 2</th>
              <th>Title 3</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Data 1</td>
              <td>Data 2</td>
              <td>Data 3</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js'></script>
<script src='https://cdn.datatables.net/t/bs/jq-2.2.0,dt-1.10.11/datatables.min.js'></script>

    <script  src="js/index.js"></script>

</body>
</html>
