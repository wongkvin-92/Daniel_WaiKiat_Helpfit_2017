var reviewTable = $('.datatable').DataTable();

$(document).ready(function() {
  $('#test').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    console.log(id);
    /*
    $.ajax({

      url: 'getSiDTrainerReview.php',
      data:{
        session_id: id
      },
      success: function(e){
        console.log(e);
      }
    });*/
    $('.datatable').dasd = 123;
    $.ajax({

      url: 'getSiDTrainerReview.php',
      data:{
        session_id: id
      },
      dataType: 'json',
      success: function(e){
        var reviewTable = $('.datatable').DataTable();
        reviewTable.clear();
        console.log(e.data);
        if(e){
          e.data.forEach( field => reviewTable.row.add(field) );
          reviewTable.draw();
        }
        else{
          alert('There is no reviews from member!');
        }
      }
    });


    $(".idhere").html(id);
  });
});
