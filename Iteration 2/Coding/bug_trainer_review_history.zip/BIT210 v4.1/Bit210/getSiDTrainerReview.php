<?php
$sid = $_GET['session_id'];


    include("config.php");

    $result2 = $conn->query("SELECT member.fullName, review.Rating, review.comment, review.currentDateTime  FROM trainingsession INNER JOIN review ON review.sessionID = trainingsession.sessionID INNER JOIN member ON review.memberID = member.memberID WHERE review.sessionID = '$sid';");
    $rs2 = $result2->fetch_all();

    print json_encode(["data" => $rs2]);

?>
