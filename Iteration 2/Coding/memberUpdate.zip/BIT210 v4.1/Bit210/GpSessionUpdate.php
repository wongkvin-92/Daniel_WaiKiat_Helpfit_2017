<?php
	session_start();
	include("config.php");


	$sessionID = $_SESSION['GpSessionUpdate'];
	$countPart = $_SESSION['countPart'];

	$title = $_POST['title'];
	$date = $_POST['date'];
	$time = $_POST['time'];
	$fee = $_POST['fee'];
	$type = $_POST['classType'];
	$status = $_POST['status_update'];
	$session_id = $_POST['session_id'];

	//submit the group session update form
	if (isset($_POST['submit'])) {
		//validation if value is empty from submission amd dosplay error message
		if (!empty($title)&&!empty($date)&&!empty($time)&&!empty($fee)&&!empty($type)&&!empty($status)  ) {
			//validation of value is not numeric amd dosplay error message
			if(is_numeric($fee)){
					$sql1 = "UPDATE trainingsession SET titel='$title',date='$date',time='$time',feee='$fee', status ='$status', classType='$type'  Where sessionID = '$sessionID'";
						if ($conn->query($sql1) == TRUE && mysqli_affected_rows($conn) >0){
							echo '<script language = "javascript">';
							echo 'alert("Record Udated successfully")';
							echo '</script>';
							echo  "<script> window.location.assign('trainer_session_group_edit.php?id=$session_id'); </script>";
							$sessionID = $_SESSION['GpSessionUpdate'];
						}else{ //check if the data are same and display error message
							echo '<script language = "javascript">';
			        echo 'alert("Data existed!")';
			        echo '</script>';
			        echo  "<script> window.location.assign('trainer_session_group_edit.php?id=$session_id'); </script>";
							$sessionID = $_SESSION['GpSessionUpdate'];
						}
				} else{

					echo '<script language = "javascript">';
					echo 'alert("Fee must be in numeric format!")';
					echo '</script>';
					echo  "<script> window.location.assign('trainer_session_group_edit.php?id=$session_id'); </script>";
					$sessionID = $_SESSION['GpSessionUpdate'];
				}
			}else{

				echo '<script language = "javascript">';
				echo 'alert("All the field most be completed")';
				echo '</script>';
				echo  "<script> window.location.assign('trainer_session_group_edit.php?id=$session_id'); </script>";
				$sessionID = $_SESSION['GpSessionUpdate'];
			}}

	$conn->close();
?>
