<?php
	//error_reporting(0);
	session_start();
	$rateValue = $_POST['rating'];
  $memberID = $_SESSION['user_ID'];
	$sess_id =$_POST['session_id'];
	$comment =$_POST['comment'];


	//$rating = $ratevalue .' '.$ratevalue1.' '.$

	$conn = mysqli_connect("localhost","root","","helpfit");

	if (mysqli_connect_errno($conn)) {
		echo "Failed to connect to MySQL: ".mysqli_connect_errno();
	}

	//submit the group session update form
	if (isset($_POST['submitRating'])) {
		if($rateValue !== '0' && !empty($comment)){

			$result="SELECT trainerID from trainingsession where sessionID =  '$sess_id'";
			$result = $conn->query($result);
			$result = $result->fetch_row();
			$trainerId = $result[0];


			$insert="INSERT INTO review (Rating, comment, sessionID, memberID, trainerID) VALUES ('$rateValue','$comment','$sess_id','$memberID','$trainerId')";

			if ($conn->query($insert) == TRUE && mysqli_affected_rows($conn) >0){

				echo '<script language = "javascript">';
				echo 'alert("Your review is submitted successfully!")';
				echo '</script>';
				echo  "<script> window.location.assign('member_history.php'); </script>";
			}else
			{
				echo " Error Adding record: ".$conn->error;
				echo '<script language = "javascript">';
				echo 'alert("Your review has not submitted successfully! ")';
				echo '</script>';
				echo  "<script> window.location.assign('trainer_review.php?session_id=$sess_id'); </script>";
			}
}
else
{
	echo '<script language = "javascript">';
	echo 'alert("Please make sure all fields are filled!")';
	echo '</script>';
	echo  "<script> window.location.assign('trainer_review.php?session_id=$sess_id'); </script>";
}
}
$conn->close();
?>
