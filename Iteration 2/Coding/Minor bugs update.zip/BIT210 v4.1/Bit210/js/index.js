$(document).ready(function() {
  $('#test').on('show.bs.modal', function(e) {
    var id = $(e.relatedTarget).data('id');
    alert(id);
    $(".idhere").html(id);
  });
});


$('.datatable').DataTable()
