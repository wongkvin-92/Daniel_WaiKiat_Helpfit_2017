<?php
	session_start();
	 include("config.php");

	$sessionID = $_SESSION['PrSessionUpdate'];

	$title = $_POST['title'];
	$date = $_POST['date'];
	$time = $_POST['time'];
	$fee = $_POST['fee'];
	$notes = $_POST['notes'];
	$status = $_POST['status_update'];
	$session_id = $_POST['session_id'];
	// To submit the personal session form update and check the validation and display error message
	//or successful message
	if (isset($_POST['submit'])) {

		if (!empty($title)&&!empty($date)&&!empty($time)&&!empty($fee)&&!empty($status)) {
			if(is_numeric($fee)){

					$sql = "UPDATE trainingsession SET titel='$title',date='$date',time='$time',feee='$fee', notes='$notes', status='$status' Where sessionID = '$sessionID'";

						if ($conn->query($sql) == TRUE && mysqli_affected_rows($conn) >0){

							echo '<script language = "javascript">';
							echo 'alert("Record Updated successfully!")';
							echo '</script>';
							echo  "<script> window.location.assign('trainer_session_personal_edit.php?id=$session_id'); </script>";
							$sessionID = $_SESSION['PrSessionUpdate'];
						}
						else
						{

							echo '<script language = "javascript">';
							echo 'alert("Data Existed!")';
							echo '</script>';
							echo  "<script> window.location.assign('trainer_session_personal_edit.php?id=$session_id'); </script>";
							$sessionID = $_SESSION['PrSessionUpdate'];
						}
				} else{

					echo '<script language = "javascript">';
					echo 'alert("Fee must be in numeric format!")';
					echo '</script>';
					echo  "<script> window.location.assign('trainer_session_personal_edit.php?id=$session_id'); </script>";
					$sessionID = $_SESSION['PrSessionUpdate'];
				}
		}else{

				echo '<script language = "javascript">';
				echo 'alert("All the field most be completed")';
				echo '</script>';
				echo  "<script> window.location.assign('trainer_session_personal_edit.php?id=$session_id'); </script>";
				$sessionID = $_SESSION['PrSessionUpdate'];
			}

	}

	$conn->close();
?>
