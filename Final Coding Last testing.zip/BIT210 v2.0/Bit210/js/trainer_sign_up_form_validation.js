// Form validation code will come here.
   //Main functions
   var form = document.querySelector('form');

   form.onsubmit = function(e) {
      validateForm(e);
   }


   //Check if the value of each textbox is empty/
   function validateForm(e){
     //Validate using name from the form/
     if( document.trainer_signup.fullname.value == "" && document.trainer_signup.username.value == ""
      && document.trainer_signup.emailadd.value == "" && document.trainer_signup.password.value ==""
      && document.trainer_signup.confirmpass.value =="" && document.trainer_signup.address.value == ""
      && document.trainer_signup.Speciality.value == ""){
       alert( "Please ensure all fields are filled!" );
       //stop submission action
       e.preventDefault();
     }
     if( document.trainer_signup.fullname.value == "" ){

       //name of the form and name of the textbox will then focus/
       document.trainer_signup.fullname.focus() ;
       document.getElementById("fullname").style.border="1px solid red";
       e.preventDefault();
     } else{
       document.getElementById("fullname").style.border="1px solid green";
       validateStringInput();
     }

     if( document.trainer_signup.username.value == "" ){

       document.trainer_signup.username.focus() ;
       document.getElementById("username").style.border="1px solid red";
       e.preventDefault();
     }else{
         document.getElementById("username").style.border="1px solid green";

     }

     if( document.trainer_signup.emailadd.value == ""){

         document.trainer_signup.emailadd.focus() ;
         document.getElementById("emailadd").style.border="1px solid red";
         e.preventDefault();
         }else{
           document.getElementById("emailadd").style.border="1px solid green";
           validateEmail();
      }

      if( document.trainer_signup.password.value == ""){

             document.trainer_signup.password.focus() ;
             document.getElementById("password").style.border="1px solid red";
             e.preventDefault();
      }else{
             document.getElementById("password").style.border="1px solid green";
             validatePassword();
         }

      if( document.trainer_signup.confirmpass.value == ""){

               document.trainer_signup.confirmpass.focus() ;
               document.getElementById("confirmpass").style.border="1px solid red";
               e.preventDefault();
        }
             else{
               document.getElementById("confirmpass").style.border="1px solid green";
              validatePassword();
           }

           if( document.trainer_signup.address.value == ""){

                 document.trainer_signup.address.focus() ;
                 document.getElementById("address").style.border="1px solid red";
                 e.preventDefault();
               }else{
                 document.getElementById("address").style.border="1px solid green";
                 validateAddress();
               }

            if( document.trainer_signup.Speciality.value == ""){
                     document.trainer_signup.Speciality.focus() ;
                     document.getElementById("Speciality").style.border="1px solid red";
                     e.preventDefault();
            }else{
                     document.getElementById("Speciality").style.border="1px solid green";

            }

    }
   //To validate email/
   function validateEmail(){
     //Declare variable that only accept an email format inout/
     var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

     if (reg.test(document.trainer_signup.emailadd.value) == false){
       alert('Invalid Email Address');
       document.trainer_signup.emailadd.focus() ;
       //using id of the textbox and give them styling/
       document.getElementById("emailadd").style.border="1px solid red";
       document.getElementById("myAnchor").addEventListener("click", function(event){
    event.preventDefault()
});
     }else{
       document.getElementById("emailadd").style.border="1px solid green";
     }
   }
   //To validate if user is enter with alphabets value/
   function validateStringInput(){
     //Declare variable to only accept string/
     var alphaExp = /^[a-zA-Z]+$/;
     if(document.trainer_signup.fullname.value.match(alphaExp)){

       document.getElementById("fullname").style.border="1px solid green";
     }else{
       alert('Please enter only alphabets!');
       document.trainer_signup.fullname.focus() ;
       document.getElementById("fullname").style.border="1px solid red";
       document.getElementById("fullname").addEventListener("click", function(event){
    event.preventDefault()
});
     }
   }
   //TO check if the password and confirm password are same value/
   function validatePassword(){
     //Store the password field objects into variables ...
     var pass1 = document.getElementById('password');
     var pass2 = document.getElementById('confirmpass');
     //Set the colors we will be using ...
     var success = "#008000";
     var error = "#FF0000";
     //Compare the values in the password field
     //and the confirmation field
     if(password.value.length > 5){
       password.style.backgroundColor = success;
     }
     else{
       alert( "Please enter at least 6 digit!");
       document.trainer_signup.fullname.focus() ;
       document.getElementById("password").style.border="1px solid red";
       password.style.backgroundColor = error;
       document.getElementById("password").addEventListener("click", function(event){
    event.preventDefault()
});
     }

     if(pass1.value == pass2.value){
       //The passwords match.
       //Set the color to the good color and inform
       //the user that they have entered the correct password
       pass2.style.backgroundColor = success;
     }else{
       //The passwords do not match.
       //Set the color to the bad color and
       //notify the user.
       pass2.style.backgroundColor = error;
       alert("Passwords Do Not Match!");
       document.getElementById("confirmpass").addEventListener("click", function(event){
    event.preventDefault()
});
     }
   }

   //TO check if the password and confirm password are same value/
   function validateAddress(){
     //Store the password field objects into variables ...
     var add = document.getElementById('address');


     //Compare the values in the password field
     //and the confirmation field
     if(add.value.length > 5){
        document.getElementById("address").style.border="1px solid green";
     }
     else{
       alert( "Please enter at least 6 digit!");
       document.trainer_signup.address.focus() ;
       document.getElementById("address").style.border="1px solid red";
       document.getElementById("address").addEventListener("click", function(event){
    event.preventDefault()
});
     }

   }
