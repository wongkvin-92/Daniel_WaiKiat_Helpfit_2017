// Form validation code will come here.
   //Main functions
   var form = document.querySelector('form');

   form.onsubmit = function(e) {
      validateForm(e);
   }


   //Check if the value of each textbox is empty/
   function validateForm(e){
     //Validate using name from the form/
     if( document.member_signup.fullname.value == "" ){
       alert( "Please provide your name!" );
       //name of the form and name of the textbox will then focus/
       document.member_signup.fullname.focus() ;
       document.getElementById("fullname").style.border="1px solid red";
       e.preventDefault();
     } else{
       document.getElementById("fullname").style.border="1px solid green";
       validateStringInput();
   }

    if( document.member_signup.username.value == "" ){
       alert( "Please provide your username!" );
       document.member_signup.username.focus() ;
       document.getElementById("username").style.border="1px solid red";
       e.preventDefault();
       }else{
         document.getElementById("username").style.border="1px solid green";

     }

     if( document.member_signup.emailadd.value == ""){
         alert( "Please provide your email!" );
         document.member_signup.emailadd.focus() ;
         document.getElementById("emailadd").style.border="1px solid red";
         e.preventDefault();
         }else{
           document.getElementById("emailadd").style.border="1px solid green";
           validateEmail();
       }

       if( document.member_signup.password.value == ""){
             alert( "Please provide your password!" );
             document.member_signup.password.focus() ;
             document.getElementById("password").style.border="1px solid red";
             e.preventDefault();
           }else{
             document.getElementById("password").style.border="1px solid green";
         }

         if( document.member_signup.confirmpass.value == ""){
               alert( "Please provide your confirmation password!" );
               document.member_signup.confirmpass.focus() ;
               document.getElementById("confirmpass").style.border="1px solid red";
               e.preventDefault();
             }
             else{
               document.getElementById("confirmpass").style.border="1px solid green";

           }

           if( document.member_signup.address.value == ""){
                 alert( "Please provide your address!" );
                 document.member_signup.address.focus() ;
                 document.getElementById("address").style.border="1px solid red";
                 e.preventDefault();
               }else{
                 document.getElementById("address").style.border="1px solid green";
               }


             if ( document.getElementsByName('level')[0].value == "level" ){
                   alert( "Please select the option from the dropdown list!" );
                   document.getElementById("level").style.border="1px solid red";
                   e.preventDefault();
                 }else{
                   document.getElementById("level").style.border="1px solid green";
                 }

    }
   //To validate email/
   function validateEmail(){
     //Declare variable that only accept an email format inout/
     var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

     if (reg.test(document.member_signup.emailadd.value) == false){
       alert('Invalid Email Address');
       document.member_signup.emailadd.focus() ;
       //using id of the textbox and give them styling/
       document.getElementById("emailadd").style.border="1px solid red";
       e.preventDefault();
     }else{
       document.getElementById("emailadd").style.border="1px solid green";
     }
   }
   //To validate if user is enter with alphabets value/
   function validateStringInput(){
     //Declare variable to only accept string/
     var alphaExp = /^[a-zA-Z]+$/;
     if(document.member_signup.fullname.value.match(alphaExp)){

       document.getElementById("fullname").style.border="1px solid green";
     }else{
       alert('Please enter only alphabets!');
       document.member_signup.fullname.focus() ;
       document.getElementById("fullname").style.border="1px solid red";
       e.preventDefault();
     }
   }
   //TO check if the password and confirm password are same value/
   function validatePassword(){
     //Store the password field objects into variables ...
     var pass1 = document.getElementById('password');
     var pass2 = document.getElementById('confirmpass');
     //Set the colors we will be using ...
     var success = "#008000";
     var error = "#FF0000";
     //Compare the values in the password field
     //and the confirmation field
     if(password.value.length > 5){
       password.style.backgroundColor = success;
     }
     else{
       alert( "Please enter at least 6 digit!");
       document.member_signup.fullname.focus() ;
       document.getElementById("password").style.border="1px solid red";
       password.style.backgroundColor = error;
       e.preventDefault();
     }

     if(pass1.value == pass2.value){
       //The passwords match.
       //Set the color to the good color and inform
       //the user that they have entered the correct password
       pass2.style.backgroundColor = success;
     }else{
       //The passwords do not match.
       //Set the color to the bad color and
       //notify the user.
       pass2.style.backgroundColor = error;
       alert("Passwords Do Not Match!");
       e.preventDefault();
     }
   }
