<!--
   // Form validation code will come here.
   //Main functions
   function validate()
   {
     validateEmptyValue();
     validateStringInput();
     validateEmail();
     validatePassword();
   }

   /*Check if the value of each textbox is empty*/
   function validateEmptyValue(){
     /*Validate using name from the form*/
     if( document.trainer_signup.fullname.value == "" ){
       alert( "Please provide your name!" );
       /*name of the form and name of the textbox will then focus*/
       document.trainer_signup.fullname.focus() ;
       document.getElementById("fullname").style.border="1px solid red";
       return false;
     } else{
       document.getElementById("fullname").style.border="1px solid green";
       return true;

       if( document.trainer_signup.username.value == "" ){
       alert( "Please provide your username!" );
       document.trainer_signup.username.focus() ;
       document.getElementById("username").style.border="1px solid red";
       return false;
       }else{
         document.getElementById("username").style.border="1px solid green";
         return true;

         if( document.trainer_signup.emailadd.value == ""){
         alert( "Please provide your email!" );
         document.trainer_signup.emailadd.focus() ;
         document.getElementById("emailadd").style.border="1px solid red";
         return false;
         }else{
           document.getElementById("emailadd").style.border="1px solid green";
           return true;

           if( document.trainer_signup.password.value == ""){
             alert( "Please provide your password!" );
             document.trainer_signup.password.focus() ;
             document.getElementById("password").style.border="1px solid red";
             return false;
           }else{
             document.getElementById("password").style.border="1px solid green";
             return true;

             if( document.trainer_signup.confirmpass.value == ""){
               alert( "Please provide your confirmation password!" );
               document.trainer_signup.confirmpass.focus() ;
               document.getElementById("confirmpass").style.border="1px solid red";
               return false;
             }
             else{
               document.getElementById("confirmpass").style.border="1px solid green";
               return true;

               if( document.trainer_signup.address.value == ""){
                 alert( "Please provide your address!" );
                 document.trainer_signup.address.focus() ;
                 document.getElementById("address").style.border="1px solid red";
                 return false;
               }else{
                 document.getElementById("address").style.border="1px solid green";
                 return true;

                 if ( document.getElementsByName('level')[0].value == 'level' ){
                   alert( "Please select the option from the dropdown list!" );
                   document.getElementById("level").style.border="1px solid red";
                   return false;
                 }else{
                   document.getElementById("level").style.border="1px solid green";
                   return true;
                 }
               }
             }
           }
         }
       }
     }    
   }
   /*To validate email*/
   function validateEmail(){
     /*Declare variable that only accept an email format inout*/
     var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

     if (reg.test(document.trainer_signup.emailadd.value) == false){
       alert('Invalid Email Address');
       document.trainer_signup.emailadd.focus() ;
       /*using id of the textbox and give them styling*/
       document.getElementById("emailadd").style.border="1px solid red";
       return false;
     }else{

       document.getElementById("emailadd").style.border="1px solid green";
       return true;
     }
   }
   /*To validate if user is enter with alphabets value*/
   function validateStringInput(){
     /*Declare variable to only accept string*/
     var alphaExp = /^[a-zA-Z]+$/;
     if(document.trainer_signup.fullname.value.match(alphaExp)){

       document.getElementById("fullname").style.border="1px solid green";
       return true;
     }else{
       alert('Please enter only alphabets!');
       document.trainer_signup.fullname.focus() ;
       document.getElementById("fullname").style.border="1px solid red";
     }
   }
   /*TO check if the password and confirm password are same value*/
   function validatePassword(){
     //Store the password field objects into variables ...
     var pass1 = document.getElementById('password');
     var pass2 = document.getElementById('confirmpass');
     //Set the colors we will be using ...
     var success = "#008000";
     var error = "#FF0000";
     //Compare the values in the password field
     //and the confirmation field
     if(password.value.length > 5){
      /*if (pass1. == pass2) {
        password.style.backgroundColor = success;
        return true;
       }else{
          alert( "Your password doesn't match!");
           document.trainer_signup.fullname.focus() ;
           document.getElementById("password").style.border="1px solid red";
           password.style.backgroundColor = error;
           return false;
       }*/
       password.style.backgroundColor = success;
        return true;
     }
     else{
       alert( "Please enter at least 6 digit!");
       document.trainer_signup.fullname.focus() ;
       document.getElementById("password").style.border="1px solid red";
       password.style.backgroundColor = error;
       return false;
     }

     if(pass1.value == pass2.value){
       //The passwords match.
       //Set the color to the good color and inform
       //the user that they have entered the correct password
       pass2.style.backgroundColor = success;
       return true;
     }else{
       //The passwords do not match.
       //Set the color to the bad color and
       //notify the user.
       pass2.style.backgroundColor = error;
       alert("Passwords Do Not Match!");
       return false;
     }
   }
